/* ── RAPPORTS / STATISTIQUES ── */
function renderRapports(container) {
  container.innerHTML = `
    <div class="page-header">
      <div><h2>📈 Rapports & Statistiques</h2><div class="subtitle">Analyse de l'activité</div></div>
      <div class="page-header-actions">
        <button class="btn btn-secondary btn-sm" onclick="printRapport()">🖨️ Imprimer</button>
      </div>
    </div>
    <div class="tabs">
      <button class="tab active" onclick="switchRapport('journalier',this)">📅 Journalier</button>
      <button class="tab" onclick="switchRapport('mensuel',this)">📆 Mensuel</button>
      <button class="tab" onclick="switchRapport('produits',this)">💊 Produits</button>
      <button class="tab" onclick="switchRapport('clients_rpt',this)">👥 Clients</button>
    </div>
    <div id="rapport-content"></div>
  `;
  renderRapportJournalier();
}

function switchRapport(type, btn) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  const fns = { journalier: renderRapportJournalier, mensuel: renderRapportMensuel, produits: renderRapportProduits, clients_rpt: renderRapportClients };
  if (fns[type]) fns[type]();
}

function renderRapportJournalier() {
  const days = [];
  for (let i = 29; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i); d.setHours(0,0,0,0);
    const dEnd = new Date(d); dEnd.setHours(23,59,59,999);
    const ventes = DB.get('ventes').filter(v => v.createdAt >= d.getTime() && v.createdAt <= dEnd.getTime());
    days.push({ label: d.toLocaleDateString('fr-FR',{day:'2-digit',month:'2-digit'}), ca: ventes.reduce((s,v)=>s+(v.total||0),0), nb: ventes.length });
  }

  const maxCA = Math.max(...days.map(d=>d.ca), 1);
  document.getElementById('rapport-content').innerHTML = `
    <div class="card" style="margin-bottom:16px">
      <div class="card-title">CA des 30 derniers jours</div>
      <div style="display:flex;align-items:flex-end;gap:4px;height:160px;padding-top:10px">
        ${days.map(d => `
          <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;height:100%;cursor:pointer" title="${d.label} : ${fmt(d.ca)} (${d.nb} ventes)">
            <div style="flex:1;display:flex;align-items:flex-end;width:100%">
              <div style="width:100%;background:var(--c-primary);border-radius:3px 3px 0 0;height:${Math.round((d.ca/maxCA)*100)}%;min-height:${d.ca>0?2:0}px;transition:height .4s;opacity:.85"></div>
            </div>
            <div style="font-size:8.5px;color:var(--c-text3);writing-mode:vertical-rl;transform:rotate(180deg);height:24px;text-align:center">${d.label}</div>
          </div>
        `).join('')}
      </div>
    </div>

    <div class="table-wrap card" style="padding:0">
      <table>
        <thead><tr><th>Date</th><th>Nb ventes</th><th>CA total</th><th>Moyenne/vente</th></tr></thead>
        <tbody>
          ${days.filter(d=>d.nb>0).slice().reverse().map(d=>`<tr>
            <td>${d.label}</td>
            <td><span class="badge badge-info">${d.nb}</span></td>
            <td style="font-weight:700;color:var(--c-primary)">${fmt(d.ca)}</td>
            <td>${fmt(d.nb?Math.round(d.ca/d.nb):0)}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function renderRapportMensuel() {
  const months = [];
  for (let i = 11; i >= 0; i--) {
    const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i); d.setHours(0,0,0,0);
    const dEnd = new Date(d); dEnd.setMonth(dEnd.getMonth()+1); dEnd.setDate(0); dEnd.setHours(23,59,59,999);
    const ventes = DB.get('ventes').filter(v => v.createdAt >= d.getTime() && v.createdAt <= dEnd.getTime());
    const achats = DB.get('achats').filter(a => a.createdAt >= d.getTime() && a.createdAt <= dEnd.getTime());
    months.push({
      label: d.toLocaleDateString('fr-FR',{month:'short',year:'2-digit'}),
      ca: ventes.reduce((s,v)=>s+(v.total||0),0),
      achats: achats.reduce((s,a)=>s+(a.montantTotal||0),0),
      nb: ventes.length
    });
  }
  document.getElementById('rapport-content').innerHTML = `
    <div class="table-wrap card" style="padding:0">
      <table>
        <thead><tr><th>Mois</th><th>Nb ventes</th><th>CA ventes</th><th>Achats stock</th><th>Marge brute</th></tr></thead>
        <tbody>
          ${months.map(m=>`<tr>
            <td style="font-weight:600">${m.label}</td>
            <td>${m.nb}</td>
            <td style="font-weight:700;color:var(--c-primary)">${fmt(m.ca)}</td>
            <td style="color:var(--c-danger)">${fmt(m.achats)}</td>
            <td style="font-weight:700;color:${m.ca-m.achats>=0?'var(--c-success)':'var(--c-danger)'}">${fmt(m.ca-m.achats)}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function renderRapportProduits() {
  const ventes = DB.get('ventes');
  const map = {};
  ventes.forEach(v => (v.lignes||[]).forEach(l => {
    if (!map[l.id]) map[l.id] = { nom: l.nom, qte: 0, ca: 0 };
    map[l.id].qte += l.qte || 0;
    map[l.id].ca += l.total || 0;
  }));
  const items = Object.values(map).sort((a,b)=>b.ca-a.ca);
  document.getElementById('rapport-content').innerHTML = items.length === 0
    ? `<div class="card"><div class="empty-state"><span class="empty-icon">📊</span><h4>Aucune donnée</h4></div></div>`
    : `<div class="table-wrap card" style="padding:0"><table>
        <thead><tr><th>Rang</th><th>Médicament</th><th>Quantité vendue</th><th>CA généré</th></tr></thead>
        <tbody>
          ${items.map((p,i)=>`<tr>
            <td><span class="badge ${i<3?'badge-warning':'badge-neutral'}">${i+1}</span></td>
            <td style="font-weight:600">${p.nom}</td>
            <td>${p.qte}</td>
            <td style="font-weight:700;color:var(--c-primary)">${fmt(p.ca)}</td>
          </tr>`).join('')}
        </tbody>
      </table></div>`;
}

function renderRapportClients() {
  const ventes = DB.get('ventes');
  const clients = DB.get('clients');
  const map = {};
  ventes.filter(v=>v.clientId).forEach(v => {
    if (!map[v.clientId]) map[v.clientId] = { nom: v.clientNom, nb: 0, ca: 0 };
    map[v.clientId].nb++;
    map[v.clientId].ca += v.total || 0;
  });
  const items = Object.values(map).sort((a,b)=>b.ca-a.ca);
  document.getElementById('rapport-content').innerHTML = items.length === 0
    ? `<div class="card"><div class="empty-state"><span class="empty-icon">👥</span><h4>Aucune donnée</h4></div></div>`
    : `<div class="table-wrap card" style="padding:0"><table>
        <thead><tr><th>Client</th><th>Nb achats</th><th>Total dépensé</th><th>Panier moyen</th></tr></thead>
        <tbody>
          ${items.map(c=>`<tr>
            <td style="font-weight:600">${c.nom}</td>
            <td>${c.nb}</td>
            <td style="font-weight:700;color:var(--c-primary)">${fmt(c.ca)}</td>
            <td>${fmt(c.nb?Math.round(c.ca/c.nb):0)}</td>
          </tr>`).join('')}
        </tbody>
      </table></div>`;
}

function printRapport() {
  const ventes = DB.get('ventes');
  const total = ventes.reduce((s,v)=>s+(v.total||0),0);
  printArea(`<p><b>Total ventes :</b> ${ventes.length} | <b>CA total :</b> ${fmt(total)}</p>`, 'Rapport Statistiques');
}
