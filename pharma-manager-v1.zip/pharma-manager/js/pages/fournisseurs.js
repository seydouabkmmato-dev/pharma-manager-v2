/* ── FOURNISSEURS ── */
function renderFournisseurs(container) {
  container.innerHTML = `
    <div class="page-header">
      <div><h2>🏭 Fournisseurs</h2><div class="subtitle">Gestion des fournisseurs et grossistes</div></div>
      <div class="page-header-actions">
        <button class="btn btn-primary" onclick="openFourModal()">＋ Nouveau fournisseur</button>
      </div>
    </div>
    <div class="bar">
      <input class="search-input" placeholder="🔍 Rechercher..." oninput="refreshFours(this.value)" />
    </div>
    <div class="card" style="padding:0" id="four-card">
      <div class="table-wrap" id="four-table"></div>
    </div>
  `;
  refreshFours('');
}

function refreshFours(q = '') {
  let items = DB.get('fournisseurs');
  if (q) items = searchFilter(items, q, ['nom','contact','telephone','email','ville']);

  const el = document.getElementById('four-table');
  if (!el) return;

  if (items.length === 0) {
    el.innerHTML = `<div class="empty-state"><span class="empty-icon">🏭</span><h4>Aucun fournisseur</h4></div>`;
    return;
  }

  el.innerHTML = `
    <table>
      <thead><tr><th>Nom</th><th>Contact</th><th>Téléphone</th><th>Email</th><th>Ville</th><th>Conditions</th><th>Actions</th></tr></thead>
      <tbody>
        ${items.map(f => `<tr>
          <td style="font-weight:600">${f.nom}</td>
          <td>${f.contact||'—'}</td>
          <td>${f.telephone||'—'}</td>
          <td>${f.email||'—'}</td>
          <td>${f.ville||'—'}</td>
          <td style="font-size:12px;color:var(--c-text3)">${f.conditions||'—'}</td>
          <td>
            <div style="display:flex;gap:4px">
              <button class="btn btn-xs btn-secondary" onclick="openFourModal('${f.id}')">✏️</button>
              <button class="btn btn-xs btn-danger" onclick="deleteFour('${f.id}')">🗑️</button>
            </div>
          </td>
        </tr>`).join('')}
      </tbody>
    </table>
  `;
}

function openFourModal(id = null) {
  const f = id ? DB.getOne('fournisseurs', id) : null;
  openModal(`
    <div class="modal-header">
      <h3>${f ? 'Modifier fournisseur' : 'Nouveau fournisseur'}</h3>
      <button class="modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body">
      <div class="form-grid">
        <div class="field"><label>Nom de la société *</label><input id="f-nom" value="${f?.nom||''}" /></div>
        <div class="form-row">
          <div class="field"><label>Contact</label><input id="f-contact" value="${f?.contact||''}" /></div>
          <div class="field"><label>Téléphone</label><input id="f-tel" value="${f?.telephone||''}" /></div>
        </div>
        <div class="form-row">
          <div class="field"><label>Email</label><input type="email" id="f-email" value="${f?.email||''}" /></div>
          <div class="field"><label>Ville / Pays</label><input id="f-ville" value="${f?.ville||''}" /></div>
        </div>
        <div class="field"><label>Adresse</label><textarea id="f-adr">${f?.adresse||''}</textarea></div>
        <div class="field"><label>Conditions de paiement</label><input id="f-cond" value="${f?.conditions||''}" placeholder="30 jours fin de mois" /></div>
        <div class="field"><label>Notes</label><textarea id="f-notes">${f?.notes||''}</textarea></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
      <button class="btn btn-primary" onclick="saveFour('${id||''}')">💾 Enregistrer</button>
    </div>
  `, 'modal-lg');
}

function saveFour(id) {
  const nom = document.getElementById('f-nom').value.trim();
  if (!nom) { toast('Le nom est obligatoire', 'danger'); return; }
  const data = {
    nom,
    contact: document.getElementById('f-contact').value.trim(),
    telephone: document.getElementById('f-tel').value.trim(),
    email: document.getElementById('f-email').value.trim(),
    ville: document.getElementById('f-ville').value.trim(),
    adresse: document.getElementById('f-adr').value.trim(),
    conditions: document.getElementById('f-cond').value.trim(),
    notes: document.getElementById('f-notes').value.trim(),
  };
  if (id) { DB.update('fournisseurs', id, data); toast('Fournisseur mis à jour'); }
  else { DB.insert('fournisseurs', data); toast('Fournisseur ajouté'); }
  closeModal(); refreshFours('');
}

function deleteFour(id) {
  confirmDialog('Supprimer ce fournisseur ?', () => {
    DB.remove('fournisseurs', id); toast('Fournisseur supprimé', 'warning'); refreshFours('');
  });
}
