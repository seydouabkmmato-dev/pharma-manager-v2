/* ── ACHATS & STOCK ── */
function renderAchats(container) {
  container.innerHTML = `
    <div class="page-header">
      <div><h2>📦 Achats & Stock</h2><div class="subtitle">Réceptions et entrées en stock</div></div>
      <div class="page-header-actions">
        <button class="btn btn-primary" onclick="openAchatModal()">＋ Nouvelle réception</button>
      </div>
    </div>
    <div class="tabs">
      <button class="tab active" onclick="switchAchatTab('liste',this)">📋 Bons de réception</button>
      <button class="tab" onclick="switchAchatTab('stock',this)">📊 État du stock</button>
    </div>
    <div id="achat-content"></div>
  `;
  renderAchatListe();
}

function switchAchatTab(tab, btn) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  if (tab === 'liste') renderAchatListe();
  else renderStockView();
}

function renderAchatListe() {
  const achats = DB.get('achats').slice().reverse();
  const fours = DB.get('fournisseurs');
  document.getElementById('achat-content').innerHTML = achats.length === 0
    ? `<div class="card"><div class="empty-state"><span class="empty-icon">📦</span><h4>Aucun achat enregistré</h4></div></div>`
    : `<div class="card" style="padding:0"><div class="table-wrap"><table>
        <thead><tr><th>Numéro</th><th>Date</th><th>Fournisseur</th><th>Produits</th><th>Montant total</th><th>Actions</th></tr></thead>
        <tbody>
          ${achats.map(a => {
            const four = fours.find(f=>f.id===a.fournisseurId);
            return `<tr>
              <td style="font-family:var(--font-mono);font-size:12px">${a.numero}</td>
              <td>${fmtDate(a.createdAt)}</td>
              <td>${four?.nom||'—'}</td>
              <td>${(a.lignes||[]).length} référence(s)</td>
              <td style="font-weight:700;color:var(--c-primary)">${fmt(a.montantTotal)}</td>
              <td><button class="btn btn-xs btn-secondary" onclick="voirAchat('${a.id}')">👁️ Voir</button></td>
            </tr>`;
          }).join('')}
        </tbody>
      </table></div></div>`;
}

function renderStockView() {
  const meds = DB.get('medicaments');
  const seuil = DB.getSetting('alertStock', 10);
  const valeur = meds.reduce((s, m) => s + (m.quantite || 0) * (m.prixAchat || 0), 0);

  document.getElementById('achat-content').innerHTML = `
    <div class="stat-grid" style="margin-bottom:16px">
      <div class="stat-card" style="--stat-color:var(--c-primary)">
        <span class="stat-icon">💼</span>
        <span class="stat-value">${fmt(valeur)}</span>
        <span class="stat-label">Valeur totale du stock</span>
      </div>
      <div class="stat-card" style="--stat-color:var(--c-warning)">
        <span class="stat-icon">⚠️</span>
        <span class="stat-value">${meds.filter(m=>(m.quantite||0)<=seuil).length}</span>
        <span class="stat-label">Stocks faibles ou rupture</span>
      </div>
      <div class="stat-card" style="--stat-color:var(--c-info)">
        <span class="stat-icon">💊</span>
        <span class="stat-value">${meds.length}</span>
        <span class="stat-label">Références</span>
      </div>
    </div>
    <div class="card" style="padding:0"><div class="table-wrap"><table>
      <thead><tr><th>Médicament</th><th>Forme</th><th>Stock</th><th>Seuil</th><th>PU achat</th><th>Valeur</th><th>Expiration</th><th>Statut</th></tr></thead>
      <tbody>
        ${meds.map(m => `<tr>
          <td style="font-weight:600">${m.nom}</td>
          <td style="font-size:12px;color:var(--c-text3)">${m.forme||''}</td>
          <td style="font-family:var(--font-mono);font-weight:700">${m.quantite||0}</td>
          <td>${m.seuilAlerte||seuil}</td>
          <td>${fmt(m.prixAchat||0)}</td>
          <td style="color:var(--c-info)">${fmt((m.quantite||0)*(m.prixAchat||0))}</td>
          <td>${expiryBadge(m.dateExpiration)}</td>
          <td>${stockBadge(m.quantite||0, m.seuilAlerte||seuil)}</td>
        </tr>`).join('')}
      </tbody>
    </table></div></div>
  `;
}

function openAchatModal() {
  const fours = DB.get('fournisseurs');
  const meds = DB.get('medicaments').filter(m => m.actif !== false);

  openModal(`
    <div class="modal-header">
      <h3>＋ Nouvelle réception</h3>
      <button class="modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body">
      <div class="form-grid">
        <div class="form-row">
          <div class="field"><label>Fournisseur</label>
            <select id="a-four">
              <option value="">— Choisir —</option>
              ${fours.map(f=>`<option value="${f.id}">${f.nom}</option>`).join('')}
            </select>
          </div>
          <div class="field"><label>Date réception</label><input type="date" id="a-date" value="${new Date().toISOString().slice(0,10)}" /></div>
        </div>
        <div class="field"><label>Numéro de bon fournisseur</label><input id="a-ref" placeholder="BL-2024-001" /></div>
        <div style="border-top:1px solid var(--c-border);padding-top:12px;margin-top:4px">
          <div style="font-weight:600;font-size:13px;margin-bottom:8px">Produits reçus</div>
          <div id="achat-lignes" style="display:flex;flex-direction:column;gap:8px"></div>
          <button class="btn btn-secondary btn-sm" style="margin-top:8px;width:100%" onclick="addAchatLigne()">＋ Ajouter un produit</button>
        </div>
        <div style="display:flex;justify-content:space-between;font-weight:700;font-size:15px;padding:8px 0;border-top:1px solid var(--c-border)">
          <span>Total</span><span id="achat-total" style="color:var(--c-primary)">0 FCFA</span>
        </div>
        <div class="field"><label>Notes</label><textarea id="a-notes" rows="2"></textarea></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
      <button class="btn btn-primary" onclick="saveAchat()">💾 Enregistrer la réception</button>
    </div>
  `, 'modal-lg');

  window._achatMeds = meds;
  window._achatLignes = [];
  addAchatLigne();
}

function addAchatLigne() {
  const meds = window._achatMeds || [];
  window._achatLignes = window._achatLignes || [];
  const idx = window._achatLignes.length;
  window._achatLignes.push({ medId: '', qte: 1, prixUnit: 0 });

  const div = document.createElement('div');
  div.id = `al-${idx}`;
  div.style.cssText = 'display:grid;grid-template-columns:2fr 1fr 1fr auto;gap:8px;align-items:end';
  div.innerHTML = `
    <div class="field"><label>Médicament</label>
      <select onchange="alUpdate(${idx},'medId',this.value)">
        <option value="">— Choisir —</option>
        ${meds.map(m=>`<option value="${m.id}">${m.nom}</option>`).join('')}
      </select>
    </div>
    <div class="field"><label>Quantité</label><input type="number" min="1" value="1" oninput="alUpdate(${idx},'qte',this.value)" /></div>
    <div class="field"><label>PU achat</label><input type="number" min="0" value="0" oninput="alUpdate(${idx},'prixUnit',this.value)" /></div>
    <button class="btn btn-danger btn-sm" onclick="removeAL(${idx})">✕</button>
  `;
  document.getElementById('achat-lignes').appendChild(div);
}

function alUpdate(idx, key, val) {
  window._achatLignes[idx][key] = key==='medId' ? val : (parseFloat(val)||0);
  calcAchatTotal();
}

function removeAL(idx) {
  const el = document.getElementById(`al-${idx}`);
  if (el) el.remove();
  window._achatLignes[idx] = null;
  calcAchatTotal();
}

function calcAchatTotal() {
  const total = (window._achatLignes||[]).filter(Boolean).reduce((s,l)=>s+(l.qte||0)*(l.prixUnit||0), 0);
  const el = document.getElementById('achat-total');
  if (el) el.textContent = fmt(total);
}

function saveAchat() {
  const lignes = (window._achatLignes||[]).filter(l => l && l.medId && l.qte > 0);
  if (lignes.length === 0) { toast('Ajoutez au moins un produit', 'danger'); return; }

  // Mise à jour du stock
  lignes.forEach(l => {
    const med = DB.getOne('medicaments', l.medId);
    if (med) DB.update('medicaments', l.medId, { quantite: (med.quantite||0) + l.qte, prixAchat: l.prixUnit || med.prixAchat });
  });

  const montantTotal = lignes.reduce((s,l)=>s+l.qte*l.prixUnit,0);
  DB.insert('achats', {
    numero: docNum('ACH', DB.nextNum('achats')),
    fournisseurId: document.getElementById('a-four').value,
    reference: document.getElementById('a-ref').value.trim(),
    lignes, montantTotal,
    notes: document.getElementById('a-notes').value.trim(),
  });

  toast('Réception enregistrée — stock mis à jour');
  closeModal();
  renderAchatListe();
  updateBellBadge();
}

function voirAchat(id) {
  const a = DB.getOne('achats', id);
  if (!a) return;
  const fours = DB.get('fournisseurs');
  const f = fours.find(x=>x.id===a.fournisseurId);
  openModal(`
    <div class="modal-header"><h3>📦 ${a.numero}</h3><button class="modal-close" onclick="closeModal()">✕</button></div>
    <div class="modal-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;font-size:12.5px">
        <div><b>Fournisseur :</b> ${f?.nom||'—'}</div>
        <div><b>Date :</b> ${fmtDate(a.createdAt)}</div>
        <div><b>Ref. BL :</b> ${a.reference||'—'}</div>
        <div><b>Total :</b> <span style="color:var(--c-primary);font-weight:700">${fmt(a.montantTotal)}</span></div>
      </div>
      <div class="table-wrap"><table>
        <thead><tr><th>Produit</th><th>Quantité</th><th>PU</th><th>Total</th></tr></thead>
        <tbody>
          ${(a.lignes||[]).map(l => {
            const m = DB.getOne('medicaments', l.medId);
            return `<tr><td>${m?.nom||'—'}</td><td>${l.qte}</td><td>${fmt(l.prixUnit)}</td><td>${fmt(l.qte*l.prixUnit)}</td></tr>`;
          }).join('')}
        </tbody>
      </table></div>
    </div>
  `);
}
