/* ── UTILISATEURS & PERMISSIONS ── */
function renderUtilisateurs(container) {
  container.innerHTML = `
    <div class="page-header">
      <div><h2>👤 Utilisateurs</h2><div class="subtitle">Gestion des accès et permissions</div></div>
      <div class="page-header-actions">
        <button class="btn btn-primary" onclick="openUserModal()">＋ Nouvel utilisateur</button>
      </div>
    </div>
    <div class="card" id="users-content"></div>
  `;
  refreshUsers();
}

function refreshUsers() {
  const users = DB.get('users');
  const el = document.getElementById('users-content');
  if (!el) return;

  el.innerHTML = `
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px">
      ${users.map(u => {
        const initials = (u.nom||u.username).slice(0,2).toUpperCase();
        const roleColors = { admin:'var(--c-danger)', caissier:'var(--c-info)', magasinier:'var(--c-warning)' };
        return `
          <div style="border:1px solid var(--c-border);border-radius:var(--radius);padding:16px;background:var(--c-surface2)">
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
              <div style="width:44px;height:44px;border-radius:50%;background:var(--c-primary-light);color:var(--c-primary);font-weight:700;font-size:16px;display:flex;align-items:center;justify-content:center">${initials}</div>
              <div>
                <div style="font-weight:700;font-size:14px">${u.nom||u.username}</div>
                <div style="font-size:12px;color:var(--c-text3)">@${u.username}</div>
              </div>
              <span style="margin-left:auto;padding:2px 10px;border-radius:99px;font-size:11px;font-weight:700;background:${roleColors[u.role]||'var(--c-primary)'};color:#fff">${u.role}</span>
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between">
              <span class="badge ${u.actif===false?'badge-danger':'badge-success'}">${u.actif===false?'Inactif':'Actif'}</span>
              <div style="display:flex;gap:6px">
                <button class="btn btn-xs btn-secondary" onclick="openUserModal('${u.id}')">✏️ Modifier</button>
                ${u.username !== 'admin' ? `<button class="btn btn-xs btn-danger" onclick="deleteUser('${u.id}')">🗑️</button>` : ''}
              </div>
            </div>
          </div>
        `;
      }).join('')}
    </div>

    <div style="margin-top:20px;padding:16px;background:var(--c-surface2);border-radius:var(--radius);border:1px solid var(--c-border)">
      <div style="font-weight:700;margin-bottom:10px;font-size:13px">📋 Matrice des permissions</div>
      <div class="table-wrap"><table>
        <thead><tr><th>Fonctionnalité</th><th>Admin</th><th>Caissier</th></tr></thead>
        <tbody>
          ${[
            ['Tableau de bord','✅','✅'],['Nouvelle vente','✅','✅'],['Clients','✅','✅'],
            ['Factures','✅','✅'],['Alertes','✅','✅'],['Médicaments','✅','❌'],
            ['Catégories','✅','❌'],['Fournisseurs','✅','❌'],['Achats','✅','❌'],
            ['Rapports','✅','❌'],['Utilisateurs','✅','❌'],['Paramètres','✅','❌'],
          ].map(r=>`<tr><td>${r[0]}</td><td style="text-align:center">${r[1]}</td><td style="text-align:center">${r[2]}</td></tr>`).join('')}
        </tbody>
      </table></div>
    </div>
  `;
}

function openUserModal(id = null) {
  const u = id ? DB.getOne('users', id) : null;
  openModal(`
    <div class="modal-header">
      <h3>${u ? 'Modifier utilisateur' : 'Nouvel utilisateur'}</h3>
      <button class="modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body">
      <div class="form-grid">
        <div class="form-row">
          <div class="field"><label>Nom complet *</label><input id="u-nom" value="${u?.nom||''}" /></div>
          <div class="field"><label>Identifiant *</label><input id="u-login" value="${u?.username||''}" ${u?.username==='admin'?'disabled':''} /></div>
        </div>
        <div class="form-row">
          <div class="field"><label>Mot de passe ${u?'(laisser vide = inchangé)':'*'}</label><input type="password" id="u-pwd" /></div>
          <div class="field"><label>Rôle</label>
            <select id="u-role">
              <option value="admin" ${u?.role==='admin'?'selected':''}>Administrateur</option>
              <option value="caissier" ${u?.role==='caissier'?'selected':''}>Caissier</option>
              <option value="magasinier" ${u?.role==='magasinier'?'selected':''}>Magasinier</option>
            </select>
          </div>
        </div>
        <div class="field" style="flex-direction:row;align-items:center;gap:10px">
          <input type="checkbox" id="u-actif" ${u?.actif===false?'':'checked'} style="width:16px;height:16px" />
          <label for="u-actif" style="margin:0">Compte actif</label>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
      <button class="btn btn-primary" onclick="saveUser('${id||''}')">💾 Enregistrer</button>
    </div>
  `);
}

function saveUser(id) {
  const nom = document.getElementById('u-nom').value.trim();
  const username = document.getElementById('u-login').value.trim();
  const pwd = document.getElementById('u-pwd').value;
  if (!nom || !username) { toast('Nom et identifiant obligatoires', 'danger'); return; }
  if (!id && !pwd) { toast('Mot de passe obligatoire', 'danger'); return; }

  const data = { nom, username, role: document.getElementById('u-role').value, actif: document.getElementById('u-actif').checked };
  if (pwd) data.password = pwd;

  if (id) { DB.update('users', id, data); toast('Utilisateur mis à jour'); }
  else { DB.insert('users', data); toast('Utilisateur créé'); }
  closeModal(); refreshUsers();
}

function deleteUser(id) {
  const u = DB.getOne('users', id);
  if (u?.id === currentUser?.id) { toast('Impossible de supprimer votre propre compte', 'danger'); return; }
  confirmDialog('Supprimer cet utilisateur ?', () => {
    DB.remove('users', id); toast('Utilisateur supprimé', 'warning'); refreshUsers();
  });
}
