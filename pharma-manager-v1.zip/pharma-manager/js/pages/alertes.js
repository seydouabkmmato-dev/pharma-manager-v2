/* ── ALERTES ── */
function renderAlertes(container) {
  const meds = DB.get('medicaments');
  const credits = DB.get('credits');
  const seuil = DB.getSetting('alertStock', 10);
  const alertExpiry = DB.getSetting('alertExpiry', 30);
  const now = Date.now();

  const ruptures = meds.filter(m => (m.quantite||0) === 0);
  const faibles  = meds.filter(m => (m.quantite||0) > 0 && (m.quantite||0) <= seuil);
  const expires  = meds.filter(m => m.dateExpiration && daysLeft(m.dateExpiration) !== null && daysLeft(m.dateExpiration) <= alertExpiry);
  const creditsEchus = credits.filter(c => c.statut !== 'payé' && c.echeance && c.echeance < now);

  container.innerHTML = `
    <div class="page-header">
      <div><h2>⚠️ Alertes</h2><div class="subtitle">Surveillance automatique du stock et des créances</div></div>
      <div class="page-header-actions">
        <button class="btn btn-secondary btn-sm" onclick="printAlertes()">🖨️ Imprimer</button>
      </div>
    </div>
    <div class="stat-grid" style="margin-bottom:20px">
      <div class="stat-card" style="--stat-color:var(--c-danger)"><span class="stat-icon">🔴</span><span class="stat-value">${ruptures.length}</span><span class="stat-label">Ruptures de stock</span></div>
      <div class="stat-card" style="--stat-color:var(--c-warning)"><span class="stat-icon">🟡</span><span class="stat-value">${faibles.length}</span><span class="stat-label">Stocks faibles</span></div>
      <div class="stat-card" style="--stat-color:#9333ea"><span class="stat-icon">⏳</span><span class="stat-value">${expires.length}</span><span class="stat-label">Expirations proches/dépassées</span></div>
      <div class="stat-card" style="--stat-color:var(--c-danger)"><span class="stat-icon">⏰</span><span class="stat-value">${creditsEchus.length}</span><span class="stat-label">Crédits échus</span></div>
    </div>

    ${ruptures.length > 0 ? alertSection('🔴 Ruptures de stock', ruptures.map(m => `
      <tr><td style="font-weight:600">${m.nom}</td><td>${m.forme||''}</td>
      <td><span class="badge badge-danger">0 unités</span></td>
      <td><button class="btn btn-xs btn-primary" onclick="showPage('achats')">Commander</button></td></tr>
    `).join(''), ['Médicament','Forme','Stock','Action']) : ''}

    ${faibles.length > 0 ? alertSection('🟡 Stocks faibles', faibles.map(m => `
      <tr><td style="font-weight:600">${m.nom}</td><td>${m.forme||''}</td>
      <td><span class="badge badge-warning">${m.quantite} unités</span></td>
      <td>Seuil : ${m.seuilAlerte||seuil}</td>
      <td><button class="btn btn-xs btn-primary" onclick="showPage('achats')">Commander</button></td></tr>
    `).join(''), ['Médicament','Forme','Stock','Seuil','Action']) : ''}

    ${expires.length > 0 ? alertSection('⏳ Expirations', expires.map(m => {
      const d = daysLeft(m.dateExpiration);
      return `<tr><td style="font-weight:600">${m.nom}</td><td>${m.forme||''}</td>
        <td>${m.quantite||0} unités</td>
        <td>${expiryBadge(m.dateExpiration)}</td></tr>`;
    }).join(''), ['Médicament','Forme','Stock','Expiration']) : ''}

    ${creditsEchus.length > 0 ? alertSection('⏰ Crédits échus', creditsEchus.map(cr => `
      <tr><td style="font-weight:600">${cr.clientNom||'—'}</td>
      <td>${cr.venteNum}</td>
      <td style="color:var(--c-danger);font-weight:700">${fmt(cr.resteAPayer)}</td>
      <td style="color:var(--c-danger)">${fmtDate(cr.echeance)}</td>
      <td><button class="btn btn-xs btn-primary" onclick="encaisserCredit('${cr.id}');showPage('credits')">Encaisser</button></td></tr>
    `).join(''), ['Client','N° Vente','Reste','Échéance','Action']) : ''}

    ${ruptures.length===0&&faibles.length===0&&expires.length===0&&creditsEchus.length===0 ?
      `<div class="card"><div class="empty-state"><span class="empty-icon">✅</span><h4>Tout est en ordre !</h4><p>Aucune alerte en ce moment.</p></div></div>` : ''}
  `;
}

function alertSection(title, rows, headers) {
  return `
    <div class="card" style="margin-bottom:16px">
      <div class="card-title" style="font-size:14px;font-weight:700">${title}</div>
      <div class="table-wrap">
        <table>
          <thead><tr>${headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>
  `;
}

function printAlertes() {
  const meds = DB.get('medicaments');
  const seuil = DB.getSetting('alertStock', 10);
  const alertExpiry = DB.getSetting('alertExpiry', 30);
  const problemes = meds.filter(m => (m.quantite||0) <= seuil || (m.dateExpiration && daysLeft(m.dateExpiration) <= alertExpiry));
  const rows = problemes.map(m=>`<tr>
    <td>${m.nom}</td><td>${m.forme||''}</td><td>${m.quantite||0}</td>
    <td>${m.dateExpiration?fmtDate(m.dateExpiration):'—'}</td>
    <td>${(m.quantite||0)===0?'RUPTURE':(m.quantite||0)<=seuil?'FAIBLE':'OK'}</td>
  </tr>`).join('');
  printArea(`<table><thead><tr><th>Médicament</th><th>Forme</th><th>Stock</th><th>Expiration</th><th>Statut</th></tr></thead><tbody>${rows}</tbody></table>`, 'Rapport Alertes');
}
