/* ── NOUVELLE VENTE (POS) ── */
let panier = [];
let venteSearch = '';
let venteMedCat = '';

function renderVente(container) {
  panier = [];
  venteSearch = '';
  venteMedCat = '';
  const cats = DB.get('categories');

  container.innerHTML = `
    <div class="page-header">
      <div><h2>🛒 Nouvelle vente</h2><div class="subtitle">Point de vente</div></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 340px;gap:16px;align-items:start">

      <!-- PRODUITS -->
      <div>
        <div class="bar">
          <input class="search-input" placeholder="🔍 Rechercher médicament ou code-barres..." oninput="venteSearch=this.value;refreshProduits()" id="vente-search" />
          <select class="filter-select" onchange="venteMedCat=this.value;refreshProduits()">
            <option value="">Toutes catégories</option>
            ${cats.map(c=>`<option value="${c.id}">${c.nom}</option>`).join('')}
          </select>
        </div>
        <div id="produit-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px;max-height:calc(100vh - 230px);overflow-y:auto;padding:2px"></div>
      </div>

      <!-- PANIER -->
      <div style="position:sticky;top:0">
        <div class="card" style="padding:0">
          <div style="padding:14px 16px;border-bottom:1px solid var(--c-border);font-weight:700;font-size:14px">🧾 Panier</div>
          <div id="panier-list" style="max-height:300px;overflow-y:auto;min-height:80px"></div>
          <div style="padding:12px 16px;border-top:1px solid var(--c-border)">
            <div id="panier-totaux"></div>
            <div class="field" style="margin-top:10px">
              <label>Client (optionnel)</label>
              <select id="v-client">
                <option value="">Vente comptant</option>
                ${DB.get('clients').map(c=>`<option value="${c.id}">${c.nom}</option>`).join('')}
              </select>
            </div>
            <div class="field" style="margin-top:8px">
              <label>Mode de paiement</label>
              <select id="v-paiement" onchange="updatePanier()">
                <option value="espèces">💵 Espèces</option>
                <option value="mobile money">📱 Mobile Money</option>
                <option value="chèque">🏦 Chèque</option>
                <option value="virement">💸 Virement</option>
                <option value="credit">📋 Crédit</option>
              </select>
            </div>
            <div id="credit-fields" class="hidden" style="margin-top:8px">
              <div class="form-row">
                <div class="field"><label>Acompte versé</label><input type="number" id="v-acompte" value="0" min="0" oninput="updatePanier()" /></div>
                <div class="field"><label>Échéance crédit</label><input type="date" id="v-echeance" /></div>
              </div>
            </div>
            <div class="field" style="margin-top:8px">
              <label>Remise (%)</label>
              <input type="number" id="v-remise" value="0" min="0" max="100" oninput="updatePanier()" />
            </div>
            <div class="field" style="margin-top:8px">
              <label>Montant reçu</label>
              <input type="number" id="v-recu" value="0" min="0" oninput="updatePanier()" />
            </div>
            <div id="monnaie-line" style="font-size:13px;margin-top:6px;padding:6px 10px;background:var(--c-success-light);border-radius:6px;color:var(--c-success);font-weight:600"></div>
          </div>
          <div style="padding:12px 16px;border-top:1px solid var(--c-border);display:flex;gap:8px">
            <button class="btn btn-secondary" style="flex:1" onclick="viderPanier()">🗑️ Vider</button>
            <button class="btn btn-primary" style="flex:2" onclick="validerVente()">✅ Valider la vente</button>
          </div>
        </div>
      </div>
    </div>
  `;

  document.getElementById('v-paiement').addEventListener('change', () => {
    const isCredit = document.getElementById('v-paiement').value === 'credit';
    document.getElementById('credit-fields').classList.toggle('hidden', !isCredit);
  });

  refreshProduits();
  updatePanier();
}

function refreshProduits() {
  let meds = DB.get('medicaments').filter(m => m.actif !== false && (m.quantite || 0) > 0);
  if (venteSearch) meds = searchFilter(meds, venteSearch, ['nom','dci','codeBarre']);
  if (venteMedCat) meds = meds.filter(m => m.categorieId === venteMedCat);

  const grid = document.getElementById('produit-grid');
  if (!grid) return;

  if (meds.length === 0) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1"><span class="empty-icon">💊</span><h4>Aucun médicament disponible</h4></div>`;
    return;
  }

  grid.innerHTML = meds.map(m => {
    const inCart = panier.find(p => p.id === m.id);
    return `
      <div class="produit-card" onclick="addToCart('${m.id}')" style="
        background:var(--c-surface);border:2px solid ${inCart?'var(--c-primary)':'var(--c-border)'};
        border-radius:var(--radius);padding:12px;cursor:pointer;
        transition:all .15s;user-select:none
      " onmouseover="this.style.borderColor='var(--c-primary)'" onmouseout="this.style.borderColor='${inCart?'var(--c-primary)':'var(--c-border)'}'">
        <div style="font-size:22px;margin-bottom:6px">💊</div>
        <div style="font-weight:600;font-size:13px;line-height:1.3;margin-bottom:4px">${m.nom}</div>
        <div style="font-size:11px;color:var(--c-text3);margin-bottom:6px">${m.forme||''} ${m.dosage||''}</div>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span style="font-weight:700;color:var(--c-primary);font-size:13px">${fmt(m.prixVente)}</span>
          <span class="badge ${m.quantite<=5?'badge-warning':'badge-neutral'}" style="font-size:10px">${m.quantite}</span>
        </div>
        ${inCart ? `<div style="margin-top:6px;background:var(--c-primary-light);color:var(--c-primary);border-radius:4px;padding:2px 6px;font-size:11px;font-weight:600;text-align:center">× ${inCart.qte} dans le panier</div>` : ''}
      </div>
    `;
  }).join('');
}

function addToCart(medId) {
  const med = DB.getOne('medicaments', medId);
  if (!med) return;
  const existing = panier.find(p => p.id === medId);
  if (existing) {
    if (existing.qte >= med.quantite) { toast('Stock insuffisant', 'danger'); return; }
    existing.qte++;
    existing.total = existing.qte * existing.prixUnit;
  } else {
    panier.push({ id: medId, nom: med.nom, forme: med.forme, dosage: med.dosage, prixUnit: med.prixVente, qte: 1, total: med.prixVente, stockDispo: med.quantite });
  }
  refreshProduits();
  updatePanier();
}

function removeFromCart(i) {
  panier.splice(i, 1);
  refreshProduits();
  updatePanier();
}

function changeQte(i, delta) {
  const item = panier[i];
  const newQte = item.qte + delta;
  if (newQte <= 0) { removeFromCart(i); return; }
  if (newQte > item.stockDispo) { toast('Stock insuffisant', 'danger'); return; }
  item.qte = newQte;
  item.total = item.qte * item.prixUnit;
  updatePanier();
}

function updatePanier() {
  const listEl = document.getElementById('panier-list');
  const totauxEl = document.getElementById('panier-totaux');
  if (!listEl) return;

  if (panier.length === 0) {
    listEl.innerHTML = `<div style="padding:24px;text-align:center;color:var(--c-text3);font-size:13px">Cliquez sur un médicament pour l'ajouter</div>`;
    totauxEl.innerHTML = '';
    document.getElementById('monnaie-line').textContent = '';
    return;
  }

  listEl.innerHTML = panier.map((item, i) => `
    <div style="padding:10px 16px;border-bottom:1px solid var(--c-border);display:flex;align-items:center;gap:8px">
      <div style="flex:1;min-width:0">
        <div style="font-weight:600;font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${item.nom}</div>
        <div style="font-size:11px;color:var(--c-text3)">${fmt(item.prixUnit)} / unité</div>
      </div>
      <div style="display:flex;align-items:center;gap:4px">
        <button class="btn btn-xs btn-secondary" onclick="changeQte(${i},-1)">−</button>
        <span style="font-weight:700;min-width:20px;text-align:center;font-size:13px">${item.qte}</span>
        <button class="btn btn-xs btn-secondary" onclick="changeQte(${i},1)">+</button>
      </div>
      <div style="font-weight:700;color:var(--c-primary);font-size:13px;min-width:70px;text-align:right">${fmt(item.total)}</div>
      <button onclick="removeFromCart(${i})" style="background:none;border:none;color:var(--c-danger);cursor:pointer;font-size:16px;padding:0 2px">✕</button>
    </div>
  `).join('');

  const sousTotal = panier.reduce((s, p) => s + p.total, 0);
  const remise = parseFloat(document.getElementById('v-remise')?.value) || 0;
  const tax = DB.getSetting('taxRate', 0);
  const remiseVal = sousTotal * remise / 100;
  const taxVal = (sousTotal - remiseVal) * tax / 100;
  const total = sousTotal - remiseVal + taxVal;

  const isCredit = document.getElementById('v-paiement')?.value === 'credit';
  const acompte = isCredit ? (parseFloat(document.getElementById('v-acompte')?.value) || 0) : 0;
  const resteAPayer = isCredit ? Math.max(0, total - acompte) : 0;
  const recu = parseFloat(document.getElementById('v-recu')?.value) || 0;
  const monnaie = isCredit ? (acompte - total) : (recu - total);

  totauxEl.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:4px;font-size:13px">
      <div style="display:flex;justify-content:space-between"><span style="color:var(--c-text2)">Sous-total</span><span>${fmt(sousTotal)}</span></div>
      ${remise > 0 ? `<div style="display:flex;justify-content:space-between;color:var(--c-danger)"><span>Remise (${remise}%)</span><span>-${fmt(remiseVal)}</span></div>` : ''}
      ${tax > 0 ? `<div style="display:flex;justify-content:space-between"><span>Taxe (${tax}%)</span><span>${fmt(taxVal)}</span></div>` : ''}
      <div style="display:flex;justify-content:space-between;font-size:16px;font-weight:800;padding:8px 0;border-top:1px solid var(--c-border);margin-top:4px">
        <span>TOTAL</span><span style="color:var(--c-primary)">${fmt(total)}</span>
      </div>
      ${isCredit && resteAPayer > 0 ? `<div style="display:flex;justify-content:space-between;color:var(--c-warning)"><span>Reste à payer (crédit)</span><span>${fmt(resteAPayer)}</span></div>` : ''}
    </div>
  `;

  const monEl = document.getElementById('monnaie-line');
  if (monnaie >= 0 && (recu > 0 || (isCredit && acompte > 0))) {
    monEl.textContent = `Monnaie à rendre : ${fmt(monnaie)}`;
    monEl.style.color = 'var(--c-success)';
  } else if (monnaie < 0 && !isCredit) {
    monEl.textContent = `Manque : ${fmt(Math.abs(monnaie))}`;
    monEl.style.color = 'var(--c-danger)';
  } else {
    monEl.textContent = '';
  }
}

function viderPanier() {
  panier = [];
  refreshProduits();
  updatePanier();
}

function validerVente() {
  if (panier.length === 0) { toast('Le panier est vide', 'danger'); return; }

  const sousTotal = panier.reduce((s, p) => s + p.total, 0);
  const remise = parseFloat(document.getElementById('v-remise').value) || 0;
  const tax = DB.getSetting('taxRate', 0);
  const remiseVal = sousTotal * remise / 100;
  const taxVal = (sousTotal - remiseVal) * tax / 100;
  const total = sousTotal - remiseVal + taxVal;
  const mode = document.getElementById('v-paiement').value;
  const isCredit = mode === 'credit';
  const acompte = isCredit ? (parseFloat(document.getElementById('v-acompte').value) || 0) : total;
  const clientId = document.getElementById('v-client').value;
  const clientEl = document.getElementById('v-client');
  const clientNom = clientId ? clientEl.options[clientEl.selectedIndex].text : null;
  const echeance = isCredit ? parseDate(document.getElementById('v-echeance').value) : null;
  const num = docNum('VNT', DB.nextNum('ventes'));

  // Mise à jour du stock
  panier.forEach(item => {
    const med = DB.getOne('medicaments', item.id);
    if (med) DB.update('medicaments', item.id, { quantite: Math.max(0, (med.quantite || 0) - item.qte) });
  });

  const vente = DB.insert('ventes', {
    numero: num,
    lignes: panier.map(p => ({ ...p })),
    sousTotal, remise: remiseVal, taxe: taxVal, total,
    modePaiement: mode,
    acompte,
    resteAPayer: isCredit ? Math.max(0, total - acompte) : 0,
    clientId, clientNom,
    caissier: currentUser.nom || currentUser.username,
  });

  // Créer une fiche crédit si nécessaire
  if (isCredit && (total - acompte) > 0) {
    DB.insert('credits', {
      venteId: vente.id,
      venteNum: num,
      clientId, clientNom,
      montantTotal: total,
      acompte, resteAPayer: total - acompte,
      echeance, statut: 'en cours',
    });
  }

  toast(`Vente ${num} enregistrée !`);
  updateBellBadge();

  // Afficher le reçu
  showRecuModal(vente.id);
  panier = [];
}

function showRecuModal(venteId) {
  const v = DB.getOne('ventes', venteId);
  if (!v) return;
  const settings = DB.getSettings();

  const html = `
    <div style="max-width:320px;margin:0 auto;font-family:'Inter',sans-serif;font-size:12px">
      <div style="text-align:center;margin-bottom:12px">
        <div style="font-size:22px">💊</div>
        <div style="font-weight:800;font-size:15px">${settings.pharmacyName||'PHARMA MANAGER'}</div>
        <div style="color:#666;font-size:11px">${settings.address||''}</div>
        <div style="color:#666;font-size:11px">${settings.phone||''}</div>
      </div>
      <div style="border-top:1px dashed #ccc;border-bottom:1px dashed #ccc;padding:8px 0;margin-bottom:10px;font-size:11px">
        <div><b>Reçu :</b> ${v.numero}</div>
        <div><b>Date :</b> ${fmtDatetime(v.createdAt)}</div>
        <div><b>Caissier :</b> ${v.caissier}</div>
        ${v.clientNom ? `<div><b>Client :</b> ${v.clientNom}</div>` : ''}
      </div>
      <table style="width:100%;border-collapse:collapse;font-size:11px">
        <thead><tr><td style="font-weight:700">Produit</td><td style="text-align:center;font-weight:700">Qté</td><td style="text-align:right;font-weight:700">Total</td></tr></thead>
        <tbody>
          ${(v.lignes||[]).map(l => `<tr>
            <td style="padding:3px 0">${l.nom}</td>
            <td style="text-align:center">${l.qte}</td>
            <td style="text-align:right">${fmt(l.total)}</td>
          </tr>`).join('')}
        </tbody>
      </table>
      <div style="border-top:1px dashed #ccc;margin-top:8px;padding-top:8px">
        ${v.remise > 0 ? `<div style="display:flex;justify-content:space-between"><span>Remise</span><span>-${fmt(v.remise)}</span></div>` : ''}
        <div style="display:flex;justify-content:space-between;font-weight:800;font-size:14px;margin-top:4px">
          <span>TOTAL</span><span>${fmt(v.total)}</span>
        </div>
        <div style="display:flex;justify-content:space-between;color:#666;margin-top:2px"><span>Mode</span><span>${v.modePaiement}</span></div>
        ${v.resteAPayer > 0 ? `<div style="color:#d97706;font-weight:700;margin-top:4px">Reste à payer (crédit) : ${fmt(v.resteAPayer)}</div>` : ''}
      </div>
      <div style="text-align:center;margin-top:12px;color:#aaa;font-size:10px">Merci de votre confiance<br>MARHABA ABK TECHNOLOGY</div>
    </div>
  `;

  openModal(`
    <div class="modal-header">
      <h3>🧾 Reçu — ${v.numero}</h3>
      <button class="modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body">${html}</div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal()">Fermer</button>
      <button class="btn btn-primary" onclick="printRecuHTML(\`${html.replace(/`/g,'\\`')}\`, '${v.numero}')">🖨️ Imprimer</button>
    </div>
  `);
}

function printRecuHTML(html, num) {
  const w = window.open('', '_blank');
  w.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8">
    <title>Reçu ${num}</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>body{margin:20px;font-family:'Inter',sans-serif}@media print{body{margin:0}}</style>
  </head><body>${html}</body></html>`);
  w.document.close();
  setTimeout(() => w.print(), 500);
}

function showFacture(venteId) {
  showRecuModal(venteId);
}
