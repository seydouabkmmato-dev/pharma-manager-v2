/* ── CLIENTS ── */
function renderClients(container) {
  container.innerHTML = `
    <div class="page-header">
      <div><h2>👥 Clients</h2><div class="subtitle">Gestion de la clientèle</div></div>
      <div class="page-header-actions">
        <button class="btn btn-primary" onclick="openClientModal()">＋ Nouveau client</button>
      </div>
    </div>
    <div class="bar">
      <input class="search-input" placeholder="🔍 Rechercher un client..." oninput="refreshClients(this.value)" />
    </div>
    <div class="card" style="padding:0"><div class="table-wrap" id="clients-table"></div></div>
  `;
  refreshClients('');
}

function refreshClients(q = '') {
  let items = DB.get('clients');
  if (q) items = searchFilter(items, q, ['nom','telephone','email','adresse']);
  const ventes = DB.get('ventes');
  const el = document.getElementById('clients-table');
  if (!el) return;

  if (items.length === 0) {
    el.innerHTML = `<div class="empty-state"><span class="empty-icon">👥</span><h4>Aucun client</h4><p>Ajoutez vos premiers clients</p></div>`;
    return;
  }

  el.innerHTML = `<table>
    <thead><tr><th>Nom</th><th>Téléphone</th><th>Email</th><th>Total achats</th><th>Nombre ventes</th><th>Actions</th></tr></thead>
    <tbody>
      ${items.map(c => {
        const cv = ventes.filter(v=>v.clientId===c.id);
        const ca = cv.reduce((s,v)=>s+(v.total||0),0);
        return `<tr>
          <td><div style="font-weight:600">${c.nom}</div><div style="font-size:11px;color:var(--c-text3)">${c.adresse||''}</div></td>
          <td>${c.telephone||'—'}</td>
          <td>${c.email||'—'}</td>
          <td style="font-weight:700;color:var(--c-primary)">${fmt(ca)}</td>
          <td><span class="badge badge-info">${cv.length}</span></td>
          <td>
            <div style="display:flex;gap:4px">
              <button class="btn btn-xs btn-secondary" onclick="voirClient('${c.id}')">👁️</button>
              <button class="btn btn-xs btn-secondary" onclick="openClientModal('${c.id}')">✏️</button>
              <button class="btn btn-xs btn-danger" onclick="deleteClient('${c.id}')">🗑️</button>
            </div>
          </td>
        </tr>`;
      }).join('')}
    </tbody>
  </table>`;
}

function openClientModal(id = null) {
  const c = id ? DB.getOne('clients', id) : null;
  openModal(`
    <div class="modal-header">
      <h3>${c ? 'Modifier client' : 'Nouveau client'}</h3>
      <button class="modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body">
      <div class="form-grid">
        <div class="field"><label>Nom complet *</label><input id="cl-nom" value="${c?.nom||''}" /></div>
        <div class="form-row">
          <div class="field"><label>Téléphone</label><input id="cl-tel" value="${c?.telephone||''}" /></div>
          <div class="field"><label>Email</label><input type="email" id="cl-email" value="${c?.email||''}" /></div>
        </div>
        <div class="field"><label>Adresse</label><textarea id="cl-adr">${c?.adresse||''}</textarea></div>
        <div class="field"><label>Notes</label><textarea id="cl-notes">${c?.notes||''}</textarea></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
      <button class="btn btn-primary" onclick="saveClient('${id||''}')">💾 Enregistrer</button>
    </div>
  `);
}

function saveClient(id) {
  const nom = document.getElementById('cl-nom').value.trim();
  if (!nom) { toast('Le nom est obligatoire', 'danger'); return; }
  const data = {
    nom,
    telephone: document.getElementById('cl-tel').value.trim(),
    email: document.getElementById('cl-email').value.trim(),
    adresse: document.getElementById('cl-adr').value.trim(),
    notes: document.getElementById('cl-notes').value.trim(),
  };
  if (id) { DB.update('clients', id, data); toast('Client mis à jour'); }
  else { DB.insert('clients', data); toast('Client ajouté'); }
  closeModal(); refreshClients('');
}

function voirClient(id) {
  const c = DB.getOne('clients', id);
  if (!c) return;
  const ventes = DB.get('ventes').filter(v=>v.clientId===id);
  const credits = DB.get('credits').filter(cr=>cr.clientId===id && cr.statut!=='payé');
  openModal(`
    <div class="modal-header"><h3>👤 ${c.nom}</h3><button class="modal-close" onclick="closeModal()">✕</button></div>
    <div class="modal-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:16px;font-size:13px">
        <div><b>📞</b> ${c.telephone||'—'}</div>
        <div><b>📧</b> ${c.email||'—'}</div>
        <div style="grid-column:1/-1"><b>📍</b> ${c.adresse||'—'}</div>
      </div>
      <div class="stat-grid" style="margin-bottom:14px">
        <div class="stat-card" style="--stat-color:var(--c-primary)">
          <span class="stat-icon">💰</span>
          <span class="stat-value">${fmt(ventes.reduce((s,v)=>s+(v.total||0),0))}</span>
          <span class="stat-label">Total achats</span>
        </div>
        <div class="stat-card" style="--stat-color:var(--c-warning)">
          <span class="stat-icon">💳</span>
          <span class="stat-value">${fmt(credits.reduce((s,cr)=>s+(cr.resteAPayer||0),0))}</span>
          <span class="stat-label">Créances</span>
        </div>
      </div>
      <div style="font-weight:600;margin-bottom:8px;font-size:13px">Historique des ventes (${ventes.length})</div>
      ${ventes.length===0?'<p style="color:var(--c-text3);font-size:13px">Aucune vente</p>':`
      <div class="table-wrap"><table>
        <thead><tr><th>N°</th><th>Date</th><th>Total</th><th>Paiement</th></tr></thead>
        <tbody>${ventes.slice(-10).reverse().map(v=>`<tr>
          <td style="font-family:var(--font-mono);font-size:11px">${v.numero}</td>
          <td>${fmtDate(v.createdAt)}</td>
          <td style="font-weight:700;color:var(--c-primary)">${fmt(v.total)}</td>
          <td>${v.modePaiement}</td>
        </tr>`).join('')}</tbody>
      </table></div>`}
    </div>
  `, 'modal-lg');
}

function deleteClient(id) {
  confirmDialog('Supprimer ce client ? Ses ventes seront conservées.', () => {
    DB.remove('clients', id); toast('Client supprimé', 'warning'); refreshClients('');
  });
}
