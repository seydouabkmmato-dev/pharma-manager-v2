/* ── CATÉGORIES ── */
function renderCategories(container) {
  container.innerHTML = `
    <div class="page-header">
      <div><h2>🗂️ Catégories</h2><div class="subtitle">Classification des médicaments</div></div>
      <div class="page-header-actions">
        <button class="btn btn-primary" onclick="openCatModal()">＋ Nouvelle catégorie</button>
      </div>
    </div>
    <div class="card" id="cat-content"></div>
  `;
  refreshCats();
}

function refreshCats() {
  const cats = DB.get('categories');
  const meds = DB.get('medicaments');
  const el = document.getElementById('cat-content');
  if (!el) return;

  if (cats.length === 0) {
    el.innerHTML = `<div class="empty-state"><span class="empty-icon">🗂️</span><h4>Aucune catégorie</h4><p>Créez des catégories pour organiser vos médicaments</p></div>`;
    return;
  }

  el.innerHTML = `
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px">
      ${cats.map(c => {
        const count = meds.filter(m => m.categorieId === c.id).length;
        return `
          <div style="border:1px solid var(--c-border);border-radius:var(--radius);padding:16px;background:var(--c-surface2);display:flex;flex-direction:column;gap:10px">
            <div style="display:flex;align-items:flex-start;justify-content:space-between">
              <div>
                <div style="font-size:26px">${c.icone || '📦'}</div>
                <div style="font-weight:700;font-size:14px;margin-top:4px">${c.nom}</div>
                <div style="font-size:12px;color:var(--c-text3)">${c.description || ''}</div>
              </div>
              <span class="badge badge-info">${count} méd.</span>
            </div>
            <div style="display:flex;gap:6px">
              <button class="btn btn-sm btn-secondary" onclick="openCatModal('${c.id}')">✏️ Modifier</button>
              <button class="btn btn-sm btn-danger" onclick="deleteCat('${c.id}')">🗑️</button>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function openCatModal(id = null) {
  const c = id ? DB.getOne('categories', id) : null;
  openModal(`
    <div class="modal-header">
      <h3>${c ? 'Modifier catégorie' : 'Nouvelle catégorie'}</h3>
      <button class="modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body">
      <div class="form-grid">
        <div class="form-row">
          <div class="field"><label>Nom *</label><input id="c-nom" value="${c?.nom||''}" placeholder="Antibiotiques" /></div>
          <div class="field"><label>Icône</label><input id="c-ico" value="${c?.icone||'💊'}" placeholder="💊" maxlength="2" /></div>
        </div>
        <div class="field"><label>Description</label><textarea id="c-desc">${c?.description||''}</textarea></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
      <button class="btn btn-primary" onclick="saveCat('${id||''}')">💾 Enregistrer</button>
    </div>
  `);
}

function saveCat(id) {
  const nom = document.getElementById('c-nom').value.trim();
  if (!nom) { toast('Le nom est obligatoire', 'danger'); return; }
  const data = { nom, icone: document.getElementById('c-ico').value.trim() || '💊', description: document.getElementById('c-desc').value.trim() };
  if (id) { DB.update('categories', id, data); toast('Catégorie mise à jour'); }
  else { DB.insert('categories', data); toast('Catégorie créée'); }
  closeModal(); refreshCats();
}

function deleteCat(id) {
  const meds = DB.get('medicaments').filter(m => m.categorieId === id).length;
  confirmDialog(`Supprimer cette catégorie ?${meds > 0 ? ` <b>${meds}</b> médicaments seront sans catégorie.` : ''}`, () => {
    DB.remove('categories', id); toast('Catégorie supprimée', 'warning'); refreshCats();
  });
}
