/* ── MÉDICAMENTS ── */
let medPage = 1;
let medSearch = '';
let medCat = '';

function renderMedicaments(container) {
  medPage = 1; medSearch = ''; medCat = '';
  container.innerHTML = `
    <div class="page-header">
      <div><h2>💊 Médicaments</h2><div class="subtitle">Gestion du catalogue produits</div></div>
      <div class="page-header-actions">
        <button class="btn btn-secondary btn-sm" onclick="exportMeds()">⬇️ Export CSV</button>
        <button class="btn btn-primary" onclick="openMedModal()">＋ Nouveau médicament</button>
      </div>
    </div>
    <div class="bar">
      <input class="search-input" placeholder="🔍 Rechercher un médicament..." oninput="medSearch=this.value;medPage=1;refreshMeds()" id="med-search" />
      <select class="filter-select" onchange="medCat=this.value;medPage=1;refreshMeds()" id="med-cat-filter">
        <option value="">Toutes les catégories</option>
        ${DB.get('categories').map(c => `<option value="${c.id}">${c.nom}</option>`).join('')}
      </select>
    </div>
    <div class="card" style="padding:0">
      <div class="table-wrap" id="med-table"></div>
    </div>
    <div id="med-pagination" class="pagination"></div>
  `;
  refreshMeds();
}

function refreshMeds() {
  let items = DB.get('medicaments');
  if (medSearch) items = searchFilter(items, medSearch, ['nom','dci','codeBarre','fabricant']);
  if (medCat) items = items.filter(m => m.categorieId === medCat);

  const paged = paginate(items, medPage, 15);
  const cats = DB.get('categories');
  const fours = DB.get('fournisseurs');

  const tbody = paged.items.length === 0
    ? `<div class="empty-state"><span class="empty-icon">💊</span><h4>Aucun médicament trouvé</h4><p>Ajoutez votre premier médicament</p></div>`
    : `<table>
        <thead><tr><th>Nom</th><th>DCI</th><th>Catégorie</th><th>Stock</th><th>Prix vente</th><th>Expiration</th><th>Statut</th><th>Actions</th></tr></thead>
        <tbody>
          ${paged.items.map(m => {
            const cat = cats.find(c => c.id === m.categorieId);
            return `<tr>
              <td>
                <div style="font-weight:600">${m.nom}</div>
                <div style="font-size:11px;color:var(--c-text3)">${m.forme || ''} ${m.dosage || ''}</div>
              </td>
              <td style="font-size:12px;color:var(--c-text3)">${m.dci || '—'}</td>
              <td>${cat ? `<span class="badge badge-info">${cat.nom}</span>` : '—'}</td>
              <td>
                <span style="font-family:var(--font-mono);font-weight:700">${m.quantite || 0}</span>
                ${stockBadge(m.quantite, m.seuilAlerte)}
              </td>
              <td style="font-weight:600;color:var(--c-primary)">${fmt(m.prixVente)}</td>
              <td>${expiryBadge(m.dateExpiration)}</td>
              <td>${m.actif === false ? '<span class="badge badge-danger">Inactif</span>' : '<span class="badge badge-success">Actif</span>'}</td>
              <td>
                <div style="display:flex;gap:4px">
                  <button class="btn btn-xs btn-secondary" onclick="openQR('${m.id}','${m.nom.replace(/'/g,"\\'")}','${m.codeBarre||m.id}')">📱</button>
                  <button class="btn btn-xs btn-secondary" onclick="openMedModal('${m.id}')">✏️</button>
                  <button class="btn btn-xs btn-danger" onclick="deleteMed('${m.id}')">🗑️</button>
                </div>
              </td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>`;

  document.getElementById('med-table').innerHTML = tbody;
  renderPagination(document.getElementById('med-pagination'), paged, `p=>{medPage=p;refreshMeds()}`);
  document.getElementById('med-table').onclick = null;
}

function openMedModal(id = null) {
  const m = id ? DB.getOne('medicaments', id) : null;
  const cats = DB.get('categories');
  const fours = DB.get('fournisseurs');

  openModal(`
    <div class="modal-header">
      <h3>${m ? '✏️ Modifier médicament' : '＋ Nouveau médicament'}</h3>
      <button class="modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body">
      <div class="form-grid">
        <div class="form-row">
          <div class="field"><label>Nom commercial *</label><input id="m-nom" value="${m?.nom||''}" placeholder="Paracétamol 500mg" /></div>
          <div class="field"><label>DCI (générique)</label><input id="m-dci" value="${m?.dci||''}" placeholder="Paracétamol" /></div>
        </div>
        <div class="form-row">
          <div class="field"><label>Forme</label>
            <select id="m-forme">
              ${['Comprimé','Gélule','Sirop','Injectable','Pommade','Gouttes','Suppositoire','Sachet','Autre'].map(f=>`<option ${m?.forme===f?'selected':''}>${f}</option>`).join('')}
            </select>
          </div>
          <div class="field"><label>Dosage</label><input id="m-dosage" value="${m?.dosage||''}" placeholder="500mg" /></div>
        </div>
        <div class="form-row">
          <div class="field"><label>Catégorie</label>
            <select id="m-cat">
              <option value="">— Choisir —</option>
              ${cats.map(c=>`<option value="${c.id}" ${m?.categorieId===c.id?'selected':''}>${c.nom}</option>`).join('')}
            </select>
          </div>
          <div class="field"><label>Fournisseur</label>
            <select id="m-four">
              <option value="">— Choisir —</option>
              ${fours.map(f=>`<option value="${f.id}" ${m?.fournisseurId===f.id?'selected':''}>${f.nom}</option>`).join('')}
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="field"><label>Prix achat (${DB.getSetting('currency','FCFA')})</label><input type="number" id="m-pachat" value="${m?.prixAchat||''}" min="0" /></div>
          <div class="field"><label>Prix vente *</label><input type="number" id="m-pvente" value="${m?.prixVente||''}" min="0" /></div>
        </div>
        <div class="form-row">
          <div class="field"><label>Stock actuel</label><input type="number" id="m-qte" value="${m?.quantite||0}" min="0" /></div>
          <div class="field"><label>Seuil alerte</label><input type="number" id="m-seuil" value="${m?.seuilAlerte||DB.getSetting('alertStock',10)}" min="0" /></div>
        </div>
        <div class="form-row">
          <div class="field"><label>Date expiration</label><input type="date" id="m-exp" value="${fmtDateInput(m?.dateExpiration)}" /></div>
          <div class="field"><label>Code-barres</label><input id="m-code" value="${m?.codeBarre||''}" placeholder="Scannez ou saisissez" /></div>
        </div>
        <div class="form-row">
          <div class="field"><label>Fabricant</label><input id="m-fab" value="${m?.fabricant||''}" /></div>
          <div class="field"><label>Emplacement</label><input id="m-empl" value="${m?.emplacement||''}" placeholder="Étagère A3" /></div>
        </div>
        <div class="field"><label>Description / Indications</label><textarea id="m-desc">${m?.description||''}</textarea></div>
        <div class="field" style="flex-direction:row;align-items:center;gap:10px">
          <input type="checkbox" id="m-actif" ${m?.actif===false?'':'checked'} style="width:16px;height:16px" />
          <label for="m-actif" style="margin:0">Médicament actif</label>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
      <button class="btn btn-primary" onclick="saveMed('${id||''}')">💾 Enregistrer</button>
    </div>
  `, 'modal-lg');
}

function saveMed(id) {
  const nom = document.getElementById('m-nom').value.trim();
  const prixVente = parseFloat(document.getElementById('m-pvente').value) || 0;
  if (!nom) { toast('Le nom est obligatoire', 'danger'); return; }
  if (!prixVente) { toast('Le prix de vente est obligatoire', 'danger'); return; }

  const data = {
    nom,
    dci: document.getElementById('m-dci').value.trim(),
    forme: document.getElementById('m-forme').value,
    dosage: document.getElementById('m-dosage').value.trim(),
    categorieId: document.getElementById('m-cat').value,
    fournisseurId: document.getElementById('m-four').value,
    prixAchat: parseFloat(document.getElementById('m-pachat').value) || 0,
    prixVente,
    quantite: parseInt(document.getElementById('m-qte').value) || 0,
    seuilAlerte: parseInt(document.getElementById('m-seuil').value) || 10,
    dateExpiration: parseDate(document.getElementById('m-exp').value),
    codeBarre: document.getElementById('m-code').value.trim(),
    fabricant: document.getElementById('m-fab').value.trim(),
    emplacement: document.getElementById('m-empl').value.trim(),
    description: document.getElementById('m-desc').value.trim(),
    actif: document.getElementById('m-actif').checked,
  };

  if (id) { DB.update('medicaments', id, data); toast('Médicament mis à jour'); }
  else { DB.insert('medicaments', data); toast('Médicament ajouté'); }
  closeModal();
  refreshMeds();
  updateBellBadge();
}

function deleteMed(id) {
  confirmDialog('Supprimer ce médicament ? Il sera déplacé dans la corbeille.', () => {
    DB.remove('medicaments', id);
    toast('Médicament supprimé', 'warning');
    refreshMeds();
    updateBellBadge();
  });
}

function openQR(id, nom, code) {
  openModal(`
    <div class="modal-header">
      <h3>📱 Code produit — ${nom}</h3>
      <button class="modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body" style="text-align:center">
      <div id="qr-box" style="display:inline-block;padding:12px;background:#fff;border-radius:8px;margin:12px auto"></div>
      <div style="margin-top:10px;font-family:var(--font-mono);font-size:18px;letter-spacing:.15em;font-weight:700">${code}</div>
      <div style="font-size:12px;color:var(--c-text3);margin-top:4px">${nom}</div>
      <button class="btn btn-primary" style="margin-top:14px" onclick="window.print()">🖨️ Imprimer</button>
    </div>
  `);
  setTimeout(() => {
    try {
      new QRCode(document.getElementById('qr-box'), {
        text: code,
        width: 160, height: 160,
        colorDark: '#000', colorLight: '#fff',
        correctLevel: QRCode.CorrectLevel.H
      });
    } catch(e) {
      document.getElementById('qr-box').textContent = code;
    }
  }, 100);
}

function exportMeds() {
  const items = DB.get('medicaments');
  const cats = DB.get('categories');
  const cols = [
    {key:'nom',label:'Nom'},{key:'dci',label:'DCI'},{key:'forme',label:'Forme'},
    {key:'dosage',label:'Dosage'},{key:'prixVente',label:'Prix vente'},
    {key:'prixAchat',label:'Prix achat'},{key:'quantite',label:'Stock'},
    {key:'codeBarre',label:'Code-barres'},{key:'fabricant',label:'Fabricant'},
  ];
  const enriched = items.map(m => ({
    ...m,
    categorie: cats.find(c=>c.id===m.categorieId)?.nom||'',
  }));
  exportCSV(enriched, 'medicaments_' + Date.now(), cols);
}
