/* ── DASHBOARD ── */
function renderDashboard(container) {
  const settings = DB.getSettings();
  const ventes = DB.get('ventes');
  const meds = DB.get('medicaments');
  const clients = DB.get('clients');
  const credits = DB.get('credits');

  const today = new Date(); today.setHours(0,0,0,0);
  const todayTs = today.getTime();

  const ventesAujourdhui = ventes.filter(v => v.createdAt >= todayTs);
  const caAujourdhui = ventesAujourdhui.reduce((s, v) => s + (v.total || 0), 0);
  const caMois = ventes.filter(v => {
    const d = new Date(v.createdAt);
    const n = new Date();
    return d.getMonth() === n.getMonth() && d.getFullYear() === n.getFullYear();
  }).reduce((s, v) => s + (v.total || 0), 0);

  const stockFaible = meds.filter(m => (m.quantite || 0) <= DB.getSetting('alertStock', 10)).length;
  const creditsEnCours = credits.filter(c => c.statut !== 'payé').reduce((s, c) => s + (c.resteAPayer || 0), 0);
  const alertExpiry = DB.getSetting('alertExpiry', 30);
  const expires = meds.filter(m => m.dateExpiration && daysLeft(m.dateExpiration) !== null && daysLeft(m.dateExpiration) <= alertExpiry && daysLeft(m.dateExpiration) >= 0).length;

  // Ventes des 7 derniers jours
  const days7 = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i); d.setHours(0,0,0,0);
    const dEnd = new Date(d); dEnd.setHours(23,59,59,999);
    const total = ventes.filter(v => v.createdAt >= d.getTime() && v.createdAt <= dEnd.getTime()).reduce((s, v) => s + (v.total || 0), 0);
    days7.push({ label: d.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric' }), total });
  }

  const maxBar = Math.max(...days7.map(d => d.total), 1);

  // Top médicaments
  const salesMap = {};
  ventes.forEach(v => (v.lignes || []).forEach(l => {
    salesMap[l.nom] = (salesMap[l.nom] || 0) + (l.qte || 0);
  }));
  const topMeds = Object.entries(salesMap).sort((a,b) => b[1]-a[1]).slice(0,5);

  container.innerHTML = `
    <div class="stat-grid">
      <div class="stat-card" style="--stat-color:var(--c-primary)">
        <span class="stat-icon">💰</span>
        <span class="stat-value">${fmt(caAujourdhui)}</span>
        <span class="stat-label">CA Aujourd'hui (${ventesAujourdhui.length} ventes)</span>
      </div>
      <div class="stat-card" style="--stat-color:var(--c-info)">
        <span class="stat-icon">📅</span>
        <span class="stat-value">${fmt(caMois)}</span>
        <span class="stat-label">CA Ce mois</span>
      </div>
      <div class="stat-card" style="--stat-color:var(--c-warning)">
        <span class="stat-icon">⚠️</span>
        <span class="stat-value">${stockFaible}</span>
        <span class="stat-label">Stocks faibles / rupture</span>
      </div>
      <div class="stat-card" style="--stat-color:var(--c-danger)">
        <span class="stat-icon">💳</span>
        <span class="stat-value">${fmt(creditsEnCours)}</span>
        <span class="stat-label">Créances en cours</span>
      </div>
      <div class="stat-card" style="--stat-color:#9333ea">
        <span class="stat-icon">💊</span>
        <span class="stat-value">${meds.length}</span>
        <span class="stat-label">Médicaments référencés</span>
      </div>
      <div class="stat-card" style="--stat-color:var(--c-danger)">
        <span class="stat-icon">🔴</span>
        <span class="stat-value">${expires}</span>
        <span class="stat-label">Expirations proches (${alertExpiry}j)</span>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;flex-wrap:wrap">
      <!-- Graphe 7 jours -->
      <div class="card" style="grid-column:1/2">
        <div class="card-title">📊 Ventes des 7 derniers jours</div>
        <div style="display:flex;align-items:flex-end;gap:8px;height:140px;padding-top:10px">
          ${days7.map(d => `
            <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;height:100%">
              <div style="flex:1;display:flex;align-items:flex-end;width:100%">
                <div style="width:100%;background:var(--c-primary);border-radius:4px 4px 0 0;height:${Math.round((d.total/maxBar)*100)}%;min-height:${d.total>0?4:0}px;transition:height .4s"
                     title="${fmt(d.total)}"></div>
              </div>
              <div style="font-size:10px;color:var(--c-text3);text-align:center;line-height:1.2">${d.label}</div>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- Top médicaments -->
      <div class="card" style="grid-column:2/3">
        <div class="card-title">🏆 Top médicaments vendus</div>
        ${topMeds.length === 0 ? `<div class="empty-state"><span class="empty-icon">📭</span><p>Aucune vente enregistrée</p></div>` : `
        <div style="display:flex;flex-direction:column;gap:10px">
          ${topMeds.map(([nom, qte], i) => `
            <div>
              <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:3px">
                <span style="font-weight:600">${i+1}. ${nom}</span>
                <span style="color:var(--c-text3)">${qte} unités</span>
              </div>
              <div class="progress-bar"><div class="progress-fill" style="width:${Math.round((qte/topMeds[0][1])*100)}%"></div></div>
            </div>
          `).join('')}
        </div>`}
      </div>
    </div>

    <!-- Dernières ventes -->
    <div class="card" style="margin-top:16px">
      <div class="card-title">🕐 Dernières ventes</div>
      ${ventes.length === 0 ? `<div class="empty-state"><span class="empty-icon">🛒</span><h4>Aucune vente</h4><p>Commencez par enregistrer une vente</p><button class="btn btn-primary" onclick="showPage('vente')" style="margin-top:8px">Nouvelle vente</button></div>` : `
      <div class="table-wrap">
        <table>
          <thead><tr><th>Numéro</th><th>Date</th><th>Client</th><th>Total</th><th>Paiement</th><th>Action</th></tr></thead>
          <tbody>
            ${ventes.slice(-10).reverse().map(v => `
              <tr>
                <td style="font-family:var(--font-mono);font-size:12px">${v.numero}</td>
                <td>${fmtDatetime(v.createdAt)}</td>
                <td>${v.clientNom || 'Comptant'}</td>
                <td style="font-weight:700;color:var(--c-primary)">${fmt(v.total)}</td>
                <td><span class="badge ${v.modePaiement==='credit'?'badge-warning':'badge-success'}">${v.modePaiement||'espèces'}</span></td>
                <td><button class="btn btn-xs btn-secondary" onclick="showFacture('${v.id}')">🧾 Reçu</button></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>`}
    </div>
  `;
}
