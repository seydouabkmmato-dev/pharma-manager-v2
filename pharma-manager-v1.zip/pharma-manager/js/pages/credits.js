/* ── VENTES À CRÉDIT ── */
function renderCredits(container) {
  container.innerHTML = `
    <div class="page-header">
      <div><h2>💳 Ventes à crédit</h2><div class="subtitle">Suivi des créances et échéances</div></div>
      <div class="page-header-actions">
        <button class="btn btn-secondary btn-sm" onclick="exportCredits()">⬇️ Export CSV</button>
      </div>
    </div>
    <div class="bar">
      <input class="search-input" placeholder="🔍 Client, numéro..." oninput="refreshCredits(this.value,'')"/>
      <select class="filter-select" onchange="refreshCredits('',this.value)" id="cr-statut-filter">
        <option value="">Tous les statuts</option>
        <option value="en cours">En cours</option>
        <option value="partiellement payé">Partiellement payé</option>
        <option value="payé">Payé</option>
        <option value="échu">Échu</option>
      </select>
    </div>
    <div id="credits-stats" style="margin-bottom:16px"></div>
    <div class="card" style="padding:0"><div class="table-wrap" id="credits-table"></div></div>
  `;
  refreshCredits('', '');
}

function refreshCredits(q = '', statut = '') {
  const now = Date.now();
  let items = DB.get('credits');
  if (q) items = searchFilter(items, q, ['clientNom','venteNum']);
  if (statut) items = items.filter(c => c.statut === statut);

  // Stats
  const totalCreances = items.filter(c=>c.statut!=='payé').reduce((s,c)=>s+(c.resteAPayer||0),0);
  const echues = items.filter(c=>c.statut!=='payé'&&c.echeance&&c.echeance<now).length;
  const statsEl = document.getElementById('credits-stats');
  if (statsEl) statsEl.innerHTML = `
    <div class="stat-grid">
      <div class="stat-card" style="--stat-color:var(--c-warning)"><span class="stat-icon">💰</span><span class="stat-value">${fmt(totalCreances)}</span><span class="stat-label">Total créances</span></div>
      <div class="stat-card" style="--stat-color:var(--c-danger)"><span class="stat-icon">⏰</span><span class="stat-value">${echues}</span><span class="stat-label">Échéances dépassées</span></div>
      <div class="stat-card" style="--stat-color:var(--c-info)"><span class="stat-icon">📋</span><span class="stat-value">${items.filter(c=>c.statut!=='payé').length}</span><span class="stat-label">Crédits en cours</span></div>
    </div>`;

  const el = document.getElementById('credits-table');
  if (!el) return;

  if (items.length === 0) {
    el.innerHTML = `<div class="empty-state"><span class="empty-icon">💳</span><h4>Aucun crédit trouvé</h4></div>`;
    return;
  }

  el.innerHTML = `<table>
    <thead><tr><th>N° Vente</th><th>Client</th><th>Montant</th><th>Acompte</th><th>Reste</th><th>Échéance</th><th>Statut</th><th>Actions</th></tr></thead>
    <tbody>
      ${items.slice().reverse().map(cr => {
        const isEchu = cr.statut !== 'payé' && cr.echeance && cr.echeance < now;
        const days = cr.echeance ? daysLeft(cr.echeance) : null;
        return `<tr>
          <td style="font-family:var(--font-mono);font-size:12px">${cr.venteNum||'—'}</td>
          <td style="font-weight:600">${cr.clientNom||'—'}</td>
          <td>${fmt(cr.montantTotal)}</td>
          <td style="color:var(--c-success)">${fmt(cr.acompte||0)}</td>
          <td style="font-weight:700;color:${cr.resteAPayer>0?'var(--c-danger)':'var(--c-success)'}">${fmt(cr.resteAPayer||0)}</td>
          <td>${cr.echeance ? `<span style="color:${isEchu?'var(--c-danger)':days<=7?'var(--c-warning)':'inherit'}">${fmtDate(cr.echeance)}${isEchu?' ⏰':''}</span>` : '—'}</td>
          <td><span class="badge ${cr.statut==='payé'?'badge-success':isEchu?'badge-danger':'badge-warning'}">${isEchu&&cr.statut!=='payé'?'Échu':cr.statut}</span></td>
          <td>
            <div style="display:flex;gap:4px">
              ${cr.statut!=='payé'?`<button class="btn btn-xs btn-primary" onclick="encaisserCredit('${cr.id}')">💵 Encaisser</button>`:''}
              <button class="btn btn-xs btn-danger" onclick="deleteCredit('${cr.id}')">🗑️</button>
            </div>
          </td>
        </tr>`;
      }).join('')}
    </tbody>
  </table>`;
}

function encaisserCredit(id) {
  const cr = DB.getOne('credits', id);
  if (!cr) return;
  openModal(`
    <div class="modal-header"><h3>💵 Encaissement — ${cr.venteNum}</h3><button class="modal-close" onclick="closeModal()">✕</button></div>
    <div class="modal-body">
      <div style="margin-bottom:16px;padding:12px;background:var(--c-surface2);border-radius:8px;font-size:13px">
        <div><b>Client :</b> ${cr.clientNom||'—'}</div>
        <div><b>Reste à payer :</b> <span style="font-weight:700;color:var(--c-danger)">${fmt(cr.resteAPayer)}</span></div>
      </div>
      <div class="form-grid">
        <div class="field"><label>Montant encaissé *</label>
          <input type="number" id="enc-montant" value="${cr.resteAPayer}" min="0" max="${cr.resteAPayer}" />
        </div>
        <div class="field"><label>Mode de paiement</label>
          <select id="enc-mode">
            <option>Espèces</option><option>Mobile Money</option><option>Virement</option>
          </select>
        </div>
        <div class="field"><label>Notes</label><input id="enc-notes" placeholder="Commentaire..." /></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
      <button class="btn btn-primary" onclick="saveEncaissement('${id}')">✅ Confirmer</button>
    </div>
  `);
}

function saveEncaissement(id) {
  const cr = DB.getOne('credits', id);
  if (!cr) return;
  const montant = parseFloat(document.getElementById('enc-montant').value) || 0;
  if (montant <= 0) { toast('Montant invalide', 'danger'); return; }

  const nouveauReste = Math.max(0, (cr.resteAPayer || 0) - montant);
  const nouveauStatut = nouveauReste <= 0 ? 'payé' : 'partiellement payé';
  const nouveauAcompte = (cr.acompte || 0) + montant;

  DB.update('credits', id, { resteAPayer: nouveauReste, acompte: nouveauAcompte, statut: nouveauStatut });
  toast(nouveauStatut === 'payé' ? 'Crédit soldé ! ✅' : `Encaissement enregistré. Reste : ${fmt(nouveauReste)}`);
  closeModal();
  refreshCredits('', '');
  updateBellBadge();
}

function deleteCredit(id) {
  confirmDialog('Supprimer ce crédit ?', () => {
    DB.remove('credits', id); toast('Supprimé', 'warning'); refreshCredits('', '');
  });
}

function exportCredits() {
  const items = DB.get('credits');
  exportCSV(items, 'credits_' + Date.now(), [
    {key:'venteNum',label:'N° Vente'},{key:'clientNom',label:'Client'},
    {key:'montantTotal',label:'Montant'},{key:'acompte',label:'Acompte'},
    {key:'resteAPayer',label:'Reste'},{key:'statut',label:'Statut'},
  ]);
}
