/* ── PARAMÈTRES ── */
function renderParametres(container) {
  const s = DB.getSettings();
  container.innerHTML = `
    <div class="page-header">
      <div><h2>⚙️ Paramètres</h2><div class="subtitle">Configuration de PHARMA MANAGER</div></div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">

      <!-- Pharmacie -->
      <div class="card">
        <div class="card-title">🏥 Informations de la pharmacie</div>
        <div class="form-grid">
          <div class="field"><label>Nom de la pharmacie</label><input id="p-nom" value="${s.pharmacyName||''}" /></div>
          <div class="field"><label>Adresse</label><textarea id="p-adr" rows="2">${s.address||''}</textarea></div>
          <div class="form-row">
            <div class="field"><label>Téléphone</label><input id="p-tel" value="${s.phone||''}" /></div>
            <div class="field"><label>Email</label><input type="email" id="p-email" value="${s.email||''}" /></div>
          </div>
          <div class="field"><label>N° d'autorisation</label><input id="p-auth" value="${s.numAuth||''}" /></div>
        </div>
        <button class="btn btn-primary" style="margin-top:14px;width:100%" onclick="saveParamPharmacie()">💾 Enregistrer</button>
      </div>

      <!-- Ventes & Stock -->
      <div class="card">
        <div class="card-title">💱 Ventes & Stock</div>
        <div class="form-grid">
          <div class="field"><label>Devise</label>
            <select id="p-currency">
              ${['FCFA','XOF','MAD','DZD','TND','EUR','USD'].map(c=>`<option ${s.currency===c?'selected':''}>${c}</option>`).join('')}
            </select>
          </div>
          <div class="field"><label>Taux de taxe (%)</label><input type="number" id="p-tax" value="${s.taxRate||0}" min="0" max="100" /></div>
          <div class="field"><label>Seuil alerte stock faible (unités)</label><input type="number" id="p-stock-seuil" value="${s.alertStock||10}" min="1" /></div>
          <div class="field"><label>Alerte expiration (jours avant)</label><input type="number" id="p-exp-seuil" value="${s.alertExpiry||30}" min="1" /></div>
        </div>
        <button class="btn btn-primary" style="margin-top:14px;width:100%" onclick="saveParamVentes()">💾 Enregistrer</button>
      </div>

      <!-- Données -->
      <div class="card">
        <div class="card-title">💾 Sauvegarde des données</div>
        <p style="font-size:12.5px;color:var(--c-text2);margin-bottom:14px;line-height:1.6">Exportez toutes les données locales de PHARMA MANAGER en JSON pour les sauvegarder ou les transférer.</p>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn btn-primary" onclick="exporterDonnees()">⬇️ Exporter (JSON)</button>
          <button class="btn btn-secondary" onclick="importerDonnees()">⬆️ Importer (JSON)</button>
        </div>
        <input type="file" id="import-file" accept=".json" style="display:none" onchange="handleImport(this)" />
      </div>

      <!-- Remise à zéro -->
      <div class="card" style="border-color:var(--c-danger)">
        <div class="card-title" style="color:var(--c-danger)">⚠️ Zone dangereuse</div>
        <p style="font-size:12.5px;color:var(--c-text2);margin-bottom:14px;line-height:1.6">La remise à zéro supprime <b>toutes les données</b> (ventes, médicaments, clients…). Cette action est irréversible.</p>
        <button class="btn btn-danger" onclick="resetApp()">🗑️ Réinitialiser toutes les données</button>
      </div>

    </div>

    <!-- À propos -->
    <div class="card" style="margin-top:16px;text-align:center">
      <div style="font-size:32px;margin-bottom:8px">💊</div>
      <div style="font-weight:800;font-size:18px;color:var(--c-primary)">PHARMA MANAGER</div>
      <div style="font-size:12px;color:var(--c-text3);margin-top:4px">Version 1.0.0 — Données 100% locales (localStorage)</div>
      <div style="font-size:12px;color:var(--c-text3);margin-top:2px">Développé par <b>MARHABA ABK TECHNOLOGY</b></div>
      <div style="margin-top:12px;font-size:11.5px;color:var(--c-text3)">
        V2 prévue : base de données en ligne, multi-utilisateurs, synchronisation cloud
      </div>
    </div>
  `;
}

function saveParamPharmacie() {
  DB.setSetting('pharmacyName', document.getElementById('p-nom').value.trim());
  DB.setSetting('address', document.getElementById('p-adr').value.trim());
  DB.setSetting('phone', document.getElementById('p-tel').value.trim());
  DB.setSetting('email', document.getElementById('p-email').value.trim());
  DB.setSetting('numAuth', document.getElementById('p-auth').value.trim());
  toast('Informations enregistrées ✅');
}

function saveParamVentes() {
  DB.setSetting('currency', document.getElementById('p-currency').value);
  DB.setSetting('taxRate', parseFloat(document.getElementById('p-tax').value) || 0);
  DB.setSetting('alertStock', parseInt(document.getElementById('p-stock-seuil').value) || 10);
  DB.setSetting('alertExpiry', parseInt(document.getElementById('p-exp-seuil').value) || 30);
  toast('Paramètres ventes enregistrés ✅');
  updateBellBadge();
}

function exporterDonnees() {
  const data = localStorage.getItem('pharma_manager_v1') || '{}';
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'pharma_backup_' + new Date().toISOString().slice(0,10) + '.json';
  a.click();
  URL.revokeObjectURL(url);
  toast('Données exportées');
}

function importerDonnees() {
  document.getElementById('import-file').click();
}

function handleImport(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      JSON.parse(e.target.result); // validation
      confirmDialog('Importer ces données ? Les données actuelles seront <b>remplacées</b>.', () => {
        localStorage.setItem('pharma_manager_v1', e.target.result);
        toast('Import réussi. Rechargement...');
        setTimeout(() => location.reload(), 1500);
      }, 'Importer');
    } catch {
      toast('Fichier invalide', 'danger');
    }
  };
  reader.readAsText(file);
  input.value = '';
}

function resetApp() {
  confirmDialog('⚠️ ATTENTION ! Toutes les données (ventes, médicaments, clients…) seront supprimées définitivement. Êtes-vous absolument sûr ?', () => {
    localStorage.removeItem('pharma_manager_v1');
    toast('Réinitialisation effectuée. Rechargement...', 'danger');
    setTimeout(() => location.reload(), 1500);
  }, '🗑️ Tout supprimer');
}
