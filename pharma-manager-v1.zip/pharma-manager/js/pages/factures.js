/* ── FACTURES & REÇUS ── */
function renderFactures(container) {
  container.innerHTML = `
    <div class="page-header">
      <div><h2>🧾 Factures & Reçus</h2><div class="subtitle">Historique complet des ventes</div></div>
      <div class="page-header-actions">
        <button class="btn btn-secondary btn-sm" onclick="exportVentes()">⬇️ Export CSV</button>
        <button class="btn btn-secondary btn-sm" onclick="printAllVentes()">🖨️ Imprimer</button>
      </div>
    </div>
    <div class="bar">
      <input class="search-input" placeholder="🔍 N° vente, client..." oninput="refreshFactures(this.value,'')" />
      <select class="filter-select" onchange="refreshFactures('',this.value)">
        <option value="">Tous les paiements</option>
        <option value="espèces">Espèces</option>
        <option value="mobile money">Mobile Money</option>
        <option value="credit">Crédit</option>
        <option value="chèque">Chèque</option>
      </select>
      <input type="date" class="filter-select" id="f-date-filter" onchange="refreshFactures('','','',this.value)" title="Filtrer par date" />
    </div>
    <div class="card" style="padding:0"><div class="table-wrap" id="factures-table"></div></div>
    <div id="factures-pagination" class="pagination"></div>
  `;
  window._factPage = 1;
  refreshFactures('', '', '', '');
}

function refreshFactures(q = '', mode = '', page = 1, date = '') {
  window._factPage = page || window._factPage || 1;
  window._factQ = q !== '' ? q : (window._factQ || '');
  window._factMode = mode !== '' ? mode : (window._factMode || '');
  window._factDate = date !== '' ? date : (window._factDate || '');

  let items = DB.get('ventes').slice().reverse();
  if (window._factQ) items = searchFilter(items, window._factQ, ['numero','clientNom','caissier']);
  if (window._factMode) items = items.filter(v => v.modePaiement === window._factMode);
  if (window._factDate) {
    const d = new Date(window._factDate); d.setHours(0,0,0,0);
    const dEnd = new Date(d); dEnd.setHours(23,59,59,999);
    items = items.filter(v => v.createdAt >= d.getTime() && v.createdAt <= dEnd.getTime());
  }

  const paged = paginate(items, window._factPage, 20);
  const el = document.getElementById('factures-table');
  if (!el) return;

  const totalPage = paged.items.reduce((s,v)=>s+(v.total||0),0);

  if (paged.items.length === 0) {
    el.innerHTML = `<div class="empty-state"><span class="empty-icon">🧾</span><h4>Aucune vente trouvée</h4></div>`;
  } else {
    el.innerHTML = `
      <table>
        <thead><tr><th>N° Vente</th><th>Date/Heure</th><th>Client</th><th>Caissier</th><th>Articles</th><th>Total</th><th>Paiement</th><th>Actions</th></tr></thead>
        <tbody>
          ${paged.items.map(v => `<tr>
            <td style="font-family:var(--font-mono);font-size:12px;font-weight:600">${v.numero}</td>
            <td style="font-size:12px">${fmtDatetime(v.createdAt)}</td>
            <td>${v.clientNom||'<span style="color:var(--c-text3)">Comptant</span>'}</td>
            <td style="font-size:12px">${v.caissier||'—'}</td>
            <td style="text-align:center"><span class="badge badge-neutral">${(v.lignes||[]).length}</span></td>
            <td style="font-weight:700;color:var(--c-primary)">${fmt(v.total)}</td>
            <td><span class="badge ${v.modePaiement==='credit'?'badge-warning':v.modePaiement==='espèces'?'badge-success':'badge-info'}">${v.modePaiement||'espèces'}</span></td>
            <td>
              <div style="display:flex;gap:4px">
                <button class="btn btn-xs btn-secondary" onclick="showFacture('${v.id}')">🧾 Reçu</button>
                <button class="btn btn-xs btn-danger" onclick="deleteVente('${v.id}')">🗑️</button>
              </div>
            </td>
          </tr>`).join('')}
        </tbody>
        <tfoot><tr style="background:var(--c-surface2);font-weight:700">
          <td colspan="5" style="padding:10px 14px;font-size:12px;color:var(--c-text2)">Total affiché (${paged.count} ventes)</td>
          <td style="padding:10px 14px;color:var(--c-primary)">${fmt(items.reduce((s,v)=>s+(v.total||0),0))}</td>
          <td colspan="2"></td>
        </tr></tfoot>
      </table>`;
  }

  renderPagination(document.getElementById('factures-pagination'), paged, `p=>refreshFactures('','',p,'')`);
}

function deleteVente(id) {
  confirmDialog('Annuler cette vente ? Le stock NE sera PAS restitué automatiquement.', () => {
    DB.remove('ventes', id);
    toast('Vente annulée', 'warning');
    refreshFactures('', '', 1, '');
  });
}

function exportVentes() {
  const items = DB.get('ventes');
  exportCSV(items, 'ventes_' + Date.now(), [
    {key:'numero',label:'N°'},{key:'clientNom',label:'Client'},
    {key:'total',label:'Total'},{key:'modePaiement',label:'Paiement'},
    {key:'caissier',label:'Caissier'},
  ]);
}

function printAllVentes() {
  const items = DB.get('ventes').slice().reverse().slice(0, 50);
  const rows = items.map(v => `<tr>
    <td>${v.numero}</td><td>${fmtDatetime(v.createdAt)}</td>
    <td>${v.clientNom||'Comptant'}</td><td>${fmt(v.total)}</td>
    <td>${v.modePaiement}</td><td>${v.caissier||'—'}</td>
  </tr>`).join('');
  printArea(`<table>
    <thead><tr><th>N°</th><th>Date</th><th>Client</th><th>Total</th><th>Paiement</th><th>Caissier</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>`, 'Liste des Ventes');
}
