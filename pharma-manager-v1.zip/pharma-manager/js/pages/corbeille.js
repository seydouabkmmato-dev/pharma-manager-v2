/* ── CORBEILLE ── */
function renderCorbeille(container) {
  container.innerHTML = `
    <div class="page-header">
      <div><h2>🗑️ Corbeille</h2><div class="subtitle">Éléments supprimés — restaurables</div></div>
      <div class="page-header-actions">
        <button class="btn btn-danger btn-sm" onclick="viderCorbeille()">🗑️ Vider la corbeille</button>
      </div>
    </div>
    <div class="card" style="padding:0"><div class="table-wrap" id="corbeille-table"></div></div>
  `;
  refreshCorbeille();
}

function refreshCorbeille() {
  const items = DB.get('corbeille').slice().reverse();
  const el = document.getElementById('corbeille-table');
  if (!el) return;

  const tableLabels = {
    medicaments: '💊 Médicament', categories: '🗂️ Catégorie', fournisseurs: '🏭 Fournisseur',
    clients: '👥 Client', ventes: '🧾 Vente', credits: '💳 Crédit', achats: '📦 Achat',
    users: '👤 Utilisateur',
  };

  if (items.length === 0) {
    el.innerHTML = `<div class="empty-state"><span class="empty-icon">✅</span><h4>Corbeille vide</h4><p>Les éléments supprimés apparaîtront ici.</p></div>`;
    return;
  }

  el.innerHTML = `<table>
    <thead><tr><th>Type</th><th>Nom / Référence</th><th>Supprimé le</th><th>Actions</th></tr></thead>
    <tbody>
      ${items.map(item => {
        const label = tableLabels[item._table] || item._table;
        const name = item.nom || item.numero || item.username || item.clientNom || '—';
        return `<tr>
          <td><span class="badge badge-neutral">${label}</span></td>
          <td style="font-weight:600">${name}</td>
          <td style="font-size:12px;color:var(--c-text3)">${fmtDatetime(item.deletedAt)}</td>
          <td>
            <div style="display:flex;gap:4px">
              <button class="btn btn-xs btn-primary" onclick="restaurerItem('${item.id}')">♻️ Restaurer</button>
              <button class="btn btn-xs btn-danger" onclick="supprimerDefinitif('${item.id}','${item._table}')">✕ Supprimer</button>
            </div>
          </td>
        </tr>`;
      }).join('')}
    </tbody>
  </table>`;
}

function restaurerItem(id) {
  DB.restore(id);
  toast('Élément restauré');
  refreshCorbeille();
  updateBellBadge();
}

function supprimerDefinitif(id, table) {
  confirmDialog('Supprimer définitivement cet élément ? Cette action est irréversible.', () => {
    DB.hardDelete('corbeille', id);
    toast('Supprimé définitivement', 'warning');
    refreshCorbeille();
  });
}

function viderCorbeille() {
  const items = DB.get('corbeille');
  if (items.length === 0) { toast('Corbeille déjà vide'); return; }
  confirmDialog(`Vider la corbeille ? <b>${items.length} élément(s)</b> seront définitivement supprimés.`, () => {
    DB.save('corbeille', []);
    toast('Corbeille vidée', 'warning');
    refreshCorbeille();
  });
}
